package ca.georgebrown.comp3074.project.Route;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import ca.georgebrown.comp3074.project.R;

public class AddRouteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_route);
    }
}
