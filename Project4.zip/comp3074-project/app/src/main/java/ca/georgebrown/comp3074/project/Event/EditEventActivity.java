package ca.georgebrown.comp3074.project.Event;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import ca.georgebrown.comp3074.project.R;

public class EditEventActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_event);
    }
}
